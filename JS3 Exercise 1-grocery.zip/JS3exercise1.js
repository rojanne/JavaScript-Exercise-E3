window.onload = function onload() {

    const divContent = document.getElementById("content");
    let stringHTML = "";

    function capitalize(str) {
        const capitalized = str.charAt(0).toUpperCase() + str.slice(1);
        return capitalized;
    }

    let groceryList = {
            "meats" : ["Fish", "Chicken", "Pork", "Beef"],
            "soaps and Shampoos" : ["Head n shoulders", "safeguard", "dove", "rejoice"],
            "vegetables" : ["Carrots", "Petchay", "Talong", "Sitaw"],
            "canned goods" : ["corned beef", "sardines", "spam", "beefloaf"]
        }
        ;

    for (let key in groceryList) {
        stringHTML +=`
        <article class="title">
            <div class="list">
                <div class="column">
                    <h1>${capitalize(key)}</h1>
        `;
        for (let value of groceryList[key]) {
            stringHTML += `
                    <input type="checkbox" name="${value}" id="${value}" value="{capitalize(value)}"/>
                    <label for="${value}">${capitalize(value)}</label>
                    <br>
                `;
        }
        
        stringHTML += `
                </div>
            </div>
        </article>`
    }
    divContent.innerHTML = stringHTML;
}
